
#ifndef Neopixel_h
#define Neopixel_h

class Neopixel
{
  public:
	Neopixel();
	
	void on(void);
	void off(void);
};	

#endif