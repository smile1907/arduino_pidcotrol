
#include "Neopixel.h"
//#include <Arduino.h>

#include <Adafruit_NeoPixel.h>
#define PIN 7 //arduino pin
Adafruit_NeoPixel strip = Adafruit_NeoPixel(4, PIN, NEO_GRB + NEO_KHZ800);


Neopixel::Neopixel()
{
	strip.begin();
}

void Neopixel::on(void)
{
  strip.setPixelColor(0, strip.Color(255, 0, 0));
  strip.setPixelColor(1, strip.Color(0, 255, 0));
  strip.setPixelColor(2, strip.Color(0, 0, 255));
  strip.setPixelColor(3, strip.Color(255, 255, 0));
  strip.show();
}

void Neopixel::off(void)
{
  strip.setPixelColor(0, strip.Color(0, 0, 0));
  strip.setPixelColor(1, strip.Color(0, 0, 0));
  strip.setPixelColor(2, strip.Color(0, 0, 0));
  strip.setPixelColor(3, strip.Color(0, 0, 0));
  strip.show();
}

