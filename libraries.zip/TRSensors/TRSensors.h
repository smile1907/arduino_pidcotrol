#ifndef TRSensors_h
#define TRSensors_h

//#include "Arduino.h"

class TRSensors
{
  public:
	TRSensors();

	void AnalogRead(void);
	void readDigitalPosition(void);
	
  	void calibrate(void);
	void readCalibrated(void);
	void readAnalogPosition(void);

	unsigned char NUM; //number of Trace IR sensor
	unsigned int *senv; //reading value of Trace IR sensor	
	unsigned int *calibratedMin; //reading value Min
	unsigned int *calibratedMax; //reading value Max

	float pos; //trs.pos -1 ~ +1
};

#endif
