#include <Arduino.h>
#include "TRSensors.h"

#define Clock     13
#define Address   12
#define DataOut   11
#define CS        10

TRSensors::TRSensors()
{
	pinMode(Clock, OUTPUT);
	pinMode(Address, OUTPUT);
	pinMode(DataOut, INPUT);
	pinMode(CS, OUTPUT);  

	NUM = 5;
	
	senv = (unsigned int*)malloc(sizeof(unsigned int) * NUM);
	calibratedMin = (unsigned int*)malloc(sizeof(unsigned int) * NUM);
	calibratedMax = (unsigned int*)malloc(sizeof(unsigned int) * NUM);
	
	for(int i=0;i<NUM;i++)
	{
		calibratedMin[i] = 1023;
		calibratedMax[i] = 0;
	}
}

void TRSensors::AnalogRead(void)
{
	char i,j;
	unsigned int channel = 0;
	unsigned int values[] = {0,0,0,0,0,0,0,0};

	for(j = 0;j < NUM + 1;j++)
	{
		digitalWrite(CS,LOW);
		for(i = 0;i < 10;i++)
		{
			//0 to 4 clock transfer channel address
			if((i < 4) && (j >> (3 - i) & 0x01))
			digitalWrite(Address,HIGH);
			else
			digitalWrite(Address,LOW);

			//0 to 10 clock receives the previous conversion result
			values[j] <<= 1;
			if(digitalRead(DataOut)) 
			values[j] |= 0x01;
			digitalWrite(Clock,HIGH);
			digitalWrite(Clock,LOW);
		}
		//sent 11 to 16 clock 
		for(i = 0;i < 6;i++)
		{
			digitalWrite(Clock,HIGH);
			digitalWrite(Clock,LOW);
		}
		digitalWrite(CS,HIGH);
	}

	for(i = 0;i < NUM;i++)
	{
		senv[i] = values[i+1];
	}
}

void TRSensors::readDigitalPosition(void)
{
  unsigned int max=0, index, i;

  for(i=0;i<NUM;i++)
  {
    if(senv[i] > max) 
    {
      max = senv[i];
      index = i;
    }
  }  
 // pos = 0.5*(float)index - 1.0; //2/4 = (y-(-1))/(x-0), x(0~4), y(-1~+1)
  //limit: -1.0 <= pos <= 1.0
}


void TRSensors::calibrate(void)
{

}


void TRSensors::readCalibrated(void)
{

}



	
void TRSensors::readAnalogPosition(void)
{ 
 unsigned int i;
   float ir_pos_sum[5];
   float irvalue_sum[5];
   int m = 1000; int cut_value = 60;
   float ir_pos[5] = {-44,-22,0,22,44};
   float irmax[5] = {625, 650, 800, 627, 620}; //���� ����� �� Ȯ��  
   //�� max 625, 650, 800, 627, 620
   //�� 110, 110, 140, 110, 100
   //�� max  
   float irmin[5] = {110, 115, 150, 110, 110}; //���� ����� �� Ȯ��  
   float Adjusting_ir[5];
   float cutting_ir = 60;
   float Adjusting_ir_max = Adjusting_ir[0];
   float Total_ir_pos_sum, Total_irvalue_sum;
  
   for(i=0; i<5; i++){
    Adjusting_ir[i] = ((senv[i] - irmin[i])/(irmax[i] - irmin[i]))*m; //스케일 조정     
     if(Adjusting_ir[i] != Adjusting_ir_max){ //cutting  
      Adjusting_ir[i] = Adjusting_ir[i] - cutting_ir; 
      if(Adjusting_ir[i] < 0){
        Adjusting_ir[i] = 0;   
    }
   }
  
    ir_pos_sum[i] = Adjusting_ir[i]*ir_pos[i]; 
     irvalue_sum[i] = Adjusting_ir[i];
    
    }
      
   Total_ir_pos_sum = ir_pos_sum[0] + ir_pos_sum[1] + ir_pos_sum[2] + ir_pos_sum[3] + ir_pos_sum[4];      
   Total_irvalue_sum = irvalue_sum[0] + irvalue_sum[1] + irvalue_sum[2] + irvalue_sum[3] + irvalue_sum[4];
   
   pos = Total_ir_pos_sum/Total_irvalue_sum;
   
   
}
	
	
	

