
#include "Oled.h"
#include <Adafruit_SSD1306.h>

#define RESET 9             // OLED RES# pin14 //arduino D9 output
#define SA0   8             // OLED D/C# pin15 //arduino D8 output, data/command, SA0 p14
Adafruit_SSD1306 display(RESET, SA0);     // OLED Object
 
Oleds::Oleds()
{
	
}
	
void Oleds::setup(void)
{
	display.begin(SSD1306_SWITCHCAPVCC, 0x3C); // SSD1306_SWITCHCAPVCC = Charge pump ON// OLED address p19 write 3C, read 3D     
}

void Oleds::logo()
{
	// display LOGO
	display.clearDisplay(); 
	display.setTextColor(WHITE); 
	display.setTextSize(2);  
	display.setCursor(0,0); display.println("Capstone21");
	display.setTextSize(1); //setting following font size
	display.display();
}

void Oleds::font(int z)
{
	display.clearDisplay(); 
	display.setTextSize(z);  
	display.display();
}

void Oleds::string(char *str)
{
  display.clearDisplay();
  display.setCursor(0,0); display.print(str);
  display.display();  
}

void Oleds::string(char *str, int value)
{
  display.clearDisplay();   
  display.setCursor(0,0); display.print(str); display.print(value);
  display.display();  
}
		
void Oleds::cursor_test(int x, int y) //***********************
{
  display.clearDisplay();  
  display.setTextSize(2); //font size: 1(small), 2(big) 
  display.invertDisplay(0); // background: 0(black), 1(white)
  display.setCursor(x, y); display.println("A");
  display.display();	
}

void Oleds::position_TRsensor(float pos, unsigned int *TRsensor)
{
	unsigned int oledpos = 10.0*(pos+1.0);

	display.clearDisplay();  

  	display.setCursor(0, 3); for (int i = 0; i < 21; i++) display.print('_');   // Yellow line, font size wide, total 21 '-' fonts
  	display.setCursor(60, 6);display.print('|'); //Yellow Center: font size narrow
  	display.setCursor(oledpos * 6, 0); display.print("*"); // position bar: pos 0 ~ 20

	display.setCursor(5, 20);
	display.print(TRsensor[0]); display.print("-");
	display.print(TRsensor[1]); display.print("-");
	display.print(TRsensor[2]); display.print("-");
	display.print(TRsensor[3]); display.print("-");
	display.print(TRsensor[4]); 
	
 	display.setCursor(0, 50); display.println(" Push Joystick to Go");

	display.display();
}

void Oleds::position_run(float pos, float Kp, float Ki, float Kd, int maxspeed, int duty)
{
	unsigned int oledpos = 10.0*(pos+1.0);
	
	display.clearDisplay();  

  	display.setCursor(0, 3); for (int i = 0; i < 21; i++) display.print('_');   // Yellow line, font size wide, total 21 '-' fonts
  	display.setCursor(60, 6);display.print('|'); //Yellow Center: font size narrow
  	display.setCursor(oledpos * 6, 0); display.print("*"); // position bar: pos 0 ~ 20

	display.setCursor(0, 20);	display.print("Kp = "); display.print(Kp);
	display.setCursor(0, 30);	display.print("Ki = "); display.print(Ki);
	display.setCursor(0, 40);	display.print("Kd = "); display.print(Kd);
	display.setCursor(0, 50);	display.print("MD = "); display.print(maxspeed); //maxduty
	display.setCursor(64, 50);	display.print("PID = "); display.println(duty);

	display.display();
}

void Oleds::pid_tunning(int maxduty, float Kp, float Ki, float Kd)
{
	display.clearDisplay();  

	display.setCursor(0, 0);	display.print("Kp = "); display.print(Kp);
	display.setCursor(0, 15);	display.print("Ki = "); display.print(Ki);
	display.setCursor(0, 30);	display.print("Kd = "); display.print(Kd);
	display.setCursor(0, 45);	display.print("maxduty = "); display.print(maxduty);

	display.display();
}
