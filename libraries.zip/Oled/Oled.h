#ifndef h
#define h

class Oleds
{
  public:
	Oleds();

	void setup(void);
	void logo(void);
	void font(int z);
	void string(char *str);
	void string(char *str, int value);
	
	void cursor_test(int x, int y);
	void position_TRsensor(float pos, unsigned int *TRsensor);
	void position_run(float pos, float Kp, float Ki, float Kd, int maxspeed, int duty);
	void pid_tunning(int maxduty, float Kp, float Ki, float Kd);

};
	
#endif
