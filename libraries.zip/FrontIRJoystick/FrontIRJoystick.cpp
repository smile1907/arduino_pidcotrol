#include <Arduino.h>
#include <Wire.h>
#include "FrontIRJoystick.h"

#define Addr 0x20           // PCF8574 I2C 주소: 전방감시 IR sensor, Buzzer, Joystick 

FrontIRJoystick::FrontIRJoystick()
{
}

void FrontIRJoystick::wr(unsigned char z)
{
  Wire.beginTransmission(Addr);
  Wire.write(z);
  Wire.endTransmission(); 
}

unsigned char FrontIRJoystick::rd(void)
{
  int z = -1;
  Wire.requestFrom(Addr, 1);
  if(Wire.available()) {
    z = Wire.read();
  }
  return z;
}

void FrontIRJoystick::beep(void)
{
  wr(0xDF); //Beep ON
  delay(50);
  wr(0xFF); //Beep OFF
}

