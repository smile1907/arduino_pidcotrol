
#ifndef FrontIRJoystick_h
#define FrontIRJoystick_h

// Front IR reading values
#define IR_N 255           // 없음
#define IR_L 127           // 왼쪽장애물
#define IR_R 191           // 오른쪽장애물
#define IR_F 63            // 전면장애물

// Joystick reading values
#define DFT 255            // default 
#define JC   239           // 중앙
#define JU   254           // 위
#define JD   247           // 아래
#define JR   253           // 우
#define JL   251           // 좌

#define IJC  47            // 좌우IR가리고 중앙
#define IJU  62            // 좌우IR가리고 위
#define IJD  55            // 좌우IR가리고 아래
#define IJR  61            // 좌우IR가리고 우
#define IJL  59            // 좌우IR가리고 좌

#define ILJU  126          // 좌IR가리고 위
#define ILJD  119          // 좌IR가리고 아래
#define IRJU  190          // 우IR가리고 위
#define IRJD  183          // 우IR가리고 아래

#define ILJR  125          // 좌IR가리고 우
#define ILJL  123          // 좌IR가리고 좌
#define IRJR  189          // 우IR가리고 우
#define IRJL  187          // 우IR가리고 좌

class FrontIRJoystick
{
	public:

	FrontIRJoystick();

	void wr(unsigned char z);
	unsigned char rd(void);
	void beep(void);


};	

#endif