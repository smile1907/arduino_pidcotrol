
#ifndef Sonars_h
#define Sonars_h

extern unsigned int Cm;	//sonar distance in cm

class Sonars
{
  public:
	
	Sonars();

	void trig(void);
};	

#endif