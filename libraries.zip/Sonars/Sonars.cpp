#include <Arduino.h>
#include "Sonars.h"

#define ECHO   2            // Echo 인터럽트 //arduino D2 input
#define TRIG   3            // Timer 2 에서 정의했음 //arduino D3 output


void Sonars::trig(void)
{
	digitalWrite(TRIG, LOW);   // set trig pin low 2μs
	delayMicroseconds(10);
	
	digitalWrite(TRIG, HIGH);  
	delayMicroseconds(20);
	digitalWrite(TRIG, LOW); 
}

unsigned long echo_begin = 0; 
unsigned int Cm;	// from the echo pulse

void isr_echo(void)
{
	unsigned long tmp;
	
  	switch (digitalRead(ECHO)) // Test to see if the signal is high or low
	{
		case HIGH:				 // echo pulse start
		  echo_begin = micros(); // Save the start time
		  break;
		  
		case LOW:				 // echo pulse end
		  tmp = (micros() - echo_begin)/59;
		  //v=x/t=340 [m/s], x[m] = vt/2 = 170*t[s] = 170*t[us]/1000000 [m] = 170*t[us]/10000 [cm] = t[us]/59 [cm]
		  if((2 < tmp) && (tmp < 400)) Cm = (unsigned int)tmp;    
		  //Ultrasonic range ranging 2cm to 400cm
		  break;

		default:
		  break;
	} 
} 

Sonars::Sonars(void)
{
	pinMode(4,OUTPUT);   //SCOPE_D4, Arduino 4 pin= Ar board Yellow (top 5), GND= Yellow (bottom 4) //Oscilloscope Test in T2_isr() //Remove Jumper (IR-D4)

	pinMode(ECHO, INPUT);       // Define the ultrasonic echo input pin
	pinMode(TRIG, OUTPUT);      // Define the ultrasonic trigger input pin 
	attachInterrupt(0, isr_echo, CHANGE); 
	//0 = INT0(D2), Interrupt Service Routine, CHANGE = rising or falling edge

}