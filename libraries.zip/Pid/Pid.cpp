#include <Arduino.h>
#include "Pid.h"
#include "Motors.h"

Pid::Pid()
{
	Kp = 15.0, Kd = 110.0,  Ki = 0.00;  // for 25ms
	maxduty = 80; //255
}

void Pid::p_motor(float Pval)
{
	PID = Kp*Pval;
	
	if (PID > 0) // 0 < pos < +1    
	{
      analogWrite(PWMA, maxduty);   
	  
	  if(maxduty - PID > 0) analogWrite(PWMB, maxduty - PID); //오른쪽 B모터 감속
	  else analogWrite(PWMB, 0);
    }
	else  // -1 < pos < 0
	{
  	  if(maxduty + PID > 0) analogWrite(PWMA, maxduty + PID); //왼쪽 A모터 감속
	  else analogWrite(PWMA, 0);
	  
      analogWrite(PWMB, maxduty);
    }
}

void Pid::pid_motor(float Pval)
{

}

void Pid::p_control(float Pval){
	float error;
	float ref = 0.0;
	float steer;
	
	float Width = 0.05;
	float Width2 = Width*2.0;  
	static float errorold;
	
	static float Ki;
	Ki =  Ki * error * 5.0;



	error = ref - Pval;
	steer = Kp*error + Kd*((error-errorold)/5.0) + Ki;
	
	
	

	Dutyleft = (int)((Width*(float)maxduty - steer)/Width2);//역행렬 계산
	Dutyright = (int)((Width*(float)maxduty + steer)/Width2);
	
	errorold = error;	
}

