
#ifndef Pid_h
#define Pid_h

class Pid
{
  public:
	Pid();
	
	float Kp, Kd, Ki;
	int maxduty, PID;
	

	int Dutyleft;
	int Dutyright;

	void p_motor(float Pval);
	void pid_motor(float Pval);
	
	void p_control(float Pval);//추가 됨
};	

#endif
