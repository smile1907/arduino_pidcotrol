라이브러리 설치에 대한 정보는 다음을 참고하세요: http://www.arduino.cc/en/Guide/Libraries
