#include <Arduino.h>
#include "Motors.h"

Motors::Motors()
{
	pinMode(PWMA,OUTPUT);                     
	pinMode(AIN2,OUTPUT);      
	pinMode(AIN1,OUTPUT);
	pinMode(PWMB,OUTPUT);       
	pinMode(AIN1,OUTPUT);     
	pinMode(AIN2,OUTPUT);  

	analogWrite(PWMA, 0);
	analogWrite(PWMB, 0);
}

void Motors::forward(void)
{
	digitalWrite(AIN1,LOW); digitalWrite(AIN2,HIGH);
	digitalWrite(BIN1,LOW); digitalWrite(BIN2,HIGH); 
}

void Motors::backward(void)
{
	digitalWrite(AIN1,HIGH); digitalWrite(AIN2,LOW);
	digitalWrite(BIN1,HIGH); digitalWrite(BIN2,LOW); }

void Motors::rotate(void) // rotate left
{
	digitalWrite(AIN1,HIGH); digitalWrite(AIN2,LOW);  
	digitalWrite(BIN1,LOW);  digitalWrite(BIN2,HIGH); 
}

void Motors::stop(void)
{
	digitalWrite(AIN2,LOW);   digitalWrite(AIN1,LOW);
	digitalWrite(BIN1,LOW);   digitalWrite(BIN2,LOW); 
}



void Motors::forward(unsigned char z)
{
	digitalWrite(AIN1,LOW); digitalWrite(AIN2,HIGH);
	digitalWrite(BIN1,LOW); digitalWrite(BIN2,HIGH); 
	analogWrite(PWMA,z); analogWrite(PWMB,z);
}

void Motors::backward(unsigned char z)
{
	digitalWrite(AIN1,HIGH); digitalWrite(AIN2,LOW);
	digitalWrite(BIN1,HIGH); digitalWrite(BIN2,LOW); 
	analogWrite(PWMA,z); analogWrite(PWMB,z);
}

void Motors::rotate(unsigned char z)
{
	digitalWrite(AIN1,HIGH); digitalWrite(AIN2,LOW);  
	digitalWrite(BIN1,LOW);  digitalWrite(BIN2,HIGH);
	analogWrite(PWMA,z); analogWrite(PWMB,z);
}

void Motors::duty(int left,int right)
{
	if(left>255){
		left = 255;
	}else if(left < -255){
		left = -255;
	}

	if(right >255){
		right = 255;
	}else if(right < -255){
		right = -255;
	}

	// 왼쪽 모터
	if(left >= 0){//듀티비가 양수인 경우
		digitalWrite(AIN1,LOW);
		digitalWrite(AIN2,HIGH);
		analogWrite(PWMA,left);
	}else{//듀티비가 음수인 경우
		digitalWrite(AIN1,HIGH);
		digitalWrite(AIN2,LOW);
		analogWrite(PWMA,-left);
	}

	// 오른쪽 모터
	if(right >= 0){//듀티비가 양수인 경우
		digitalWrite(BIN1,LOW);
		digitalWrite(BIN2,HIGH);
		analogWrite(PWMB,right);
	}else{//듀티비가 음수인 경우
		digitalWrite(BIN1,HIGH);
		digitalWrite(BIN2,LOW);
		analogWrite(PWMB,-right);
	}

}

