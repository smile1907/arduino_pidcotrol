
#ifndef Motors_h
#define Motors_h

#define PWMA   6           //Left Motor duty pin (ENA)
#define AIN2   A0          //Motor-L forward (IN2).
#define AIN1   A1          //Motor-L backward (IN1)
#define PWMB   5           //Right Motor duty pin (ENB)
#define BIN1   A2          //Motor-R forward (IN3)
#define BIN2   A3          //Motor-R backward (IN4)


class Motors
{
  public:
	
	Motors();

	void forward(void);
	void backward(void);
	void rotate(void);
	void stop(void);

	void forward(unsigned char z);
	void backward(unsigned char z);
	void rotate(unsigned char z);

	void duty(int left,int right); //추가됨

};	

#endif