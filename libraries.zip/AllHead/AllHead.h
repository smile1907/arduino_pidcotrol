
#ifndef AllHead_h
#define AllHead_h

//--------------------------------------- i2c communication
#include <Wire.h>

//--------------------------------------- OLED 0.93
 #include "Oled.h" //SSD1306 128x64
Oleds oled = Oleds();

//--------------------------------------- Neopixel (Adafruit_NeoPixel 동반)
#include "Neopixel.h" //SSD1306 128x64
Neopixel rgb = Neopixel();

//--------------------------------------- TR sensor
#include "TRSensors.h"
TRSensors trs =   TRSensors();

//--------------------------------------- Fir Joystic
#include "FrontIRJoystick.h"
FrontIRJoystick fjoy =   FrontIRJoystick();

//--------------------------------------- Motors
#include "Motors.h"
Motors motor = Motors(); 

//--------------------------------------- Sonar
#include "Sonars.h"
Sonars sonar = Sonars();

//--------------------------------------- Timer 2
#include "MsTimer2.h"      // Timer 라이브러리

#define Tsampling 5 //ms, for T2_isr and Pid *****
#define Tsonar 50 //ms, for Sonar
#define Nsonar (Tsonar/Tsampling) //for Sonar
#define SCOPE_D4 (digitalWrite(4, !digitalRead(4))) //test pin toggle on Ts time

unsigned int Ts = Tsampling; //sample time variable
volatile bool TsFlag=0; //time test flag

void T2_isr() // Timer2 Interrupt Service Routine
{  
  static byte NTs = 0;
  
  TsFlag = 1;
  
  if ( ++NTs >= Nsonar )
  {
    NTs = 0;
    sonar.trig();
	SCOPE_D4;
  }
  
}

//--------------------------------------- Pid
#include "Pid.h"
Pid pid = Pid();

//--------------------------------------- HWsetup
void HWsetup(void)
{
  Serial.begin(9600);   // Arduino serial monitor speed
  Wire.begin();  // I2C start   
  
  MsTimer2::set(Ts,T2_isr); // Timer 초기화 ( Ts [ms], Interrupt Service Routine T2_isr())  
  MsTimer2::start();   

  oled.setup();
  oled.logo();
  
  rgb.on();
  delay(1000); 
  rgb.off();
}


#endif
